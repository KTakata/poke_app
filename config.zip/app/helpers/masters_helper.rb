module MastersHelper
end
