module TypeHelper
end
