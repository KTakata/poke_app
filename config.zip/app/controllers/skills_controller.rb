class SkillsController < ApplicationController
  before_filter :find_skills
  def index
    @hash_list = Type.own_lists_with_blank
  end

  def show
    @skill = Skill.find(params[:id])
  end

  private

  def find_skills
    @skills = Skill.search(params[:search_n], params[:type], params[:page])
  end
end
