class MastersController < ApplicationController
  before_filter :find_masters
  def index
    @hash_list = Type.own_lists_with_blank
  end

  def show
    @master = Master.find(params[:id])
  end

  private

  def find_masters
    @masters = Master.search(params[:search_n], params[:type], params[:page])
  end
end
