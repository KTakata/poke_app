class CharacteristicsController < ApplicationController
  before_filter :find_characteristics
  def index; end

  def show
    @characteristic = Characteristic.find_by_id(params[:id])
  end

  private

  def find_characteristics
    @characteristics = Characteristic.search(params[:search_n], params[:page])
  end
end
