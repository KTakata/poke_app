class Skill < ActiveRecord::Base
  belongs_to :type

  def self.search(search, search_type_param, param_page) # self.でクラスメソッドとしている
    search_type_id = search_type_param['search_t']
    if search != '' # Controllerから渡されたパラメータが!= nilの場合は、titleカラムを部分一致検索
      if search_type_id != ''
        Skill.where(['name LIKE ? and type_id = ?', "%#{search}%", search_type_id.to_s]).order(:name).page(param_page)
      else
        Skill.where(['name LIKE ? and pp not ?', "%#{search}%", nil]).order(:name).page(param_page)
      end
    else
      if search_type_id != ''
        Skill.where(['type_id = ?', search_type_id.to_s]).order(:name).page(param_page)
      else
        Skill.where('pp not ?', nil).order(:name).page(param_page)
      end
    end
  end
end
