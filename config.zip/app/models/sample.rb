class Sample < ActiveRecord::Base
end
