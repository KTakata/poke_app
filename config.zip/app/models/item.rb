class Item < ActiveRecord::Base
  belongs_to :item_type
end
