class Birthplace < ActiveRecord::Base
end
