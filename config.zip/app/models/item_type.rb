class ItemType < ActiveRecord::Base
end
