class Characteristic < ActiveRecord::Base
  has_many :master1, class_name: 'Master', foreign_key: 'characteristic1_id'
  has_many :master2, class_name: 'Master', foreign_key: 'characteristic2_id'
  has_many :master3, class_name: 'Master', foreign_key: 'characteristic3_id'
  def self.search(search, param_page) # self.でクラスメソッドとしている
    if search # Controllerから渡されたパラメータが!= nilの場合は、titleカラムを部分一致検索
      Characteristic.where(['name LIKE ?', "%#{search}%"]).order(:name).page(param_page)
    else
      Characteristic.order(:name).page(param_page)
    end
  end

  def master_ids
    master_ids = []
    master_ids.concat(master1_ids) if master1_ids.count != 0
    master_ids.concat(master2_ids) if master2_ids.count != 0
    master_ids.concat(master3_ids) if master3_ids.count != 0
    master_ids
  end

  def masters
    masters = Master.where(['characteristic1_id = ? or characteristic2_id = ? or characteristic3_id = ?', id, id, id])
    masters
  end
end
