class BattleType < ActiveRecord::Base
end
