class Master < ActiveRecord::Base
  belongs_to :type1, class_name: 'Type', foreign_key: 'type1_id'
  belongs_to :type2, class_name: 'Type', foreign_key: 'type2_id'
  # TODO: 中間テーブル
  belongs_to :characteristic1, class_name: 'Characteristic', foreign_key: 'characteristic1_id'
  belongs_to :characteristic2, class_name: 'Characteristic', foreign_key: 'characteristic2_id'
  belongs_to :characteristic3, class_name: 'Characteristic', foreign_key: 'characteristic3_id'

  def self.search(search, search_type_param, param_page) # self.でクラスメソッドとしている
    search_type_id = ''
    search_type_id = search_type_param['search_t'] unless search_type_param.nil?
    if search != '' # Controllerから渡されたパラメータが!= nilの場合は、titleカラムを部分一致検索
      if search_type_id != ''
        Master.where(['name LIKE ? and (type1_id = ? or type2_id = ?)', "%#{search}%", search_type_id.to_s, search_type_id.to_s]).order(:no).page(param_page)
      else
        Master.where(['name LIKE ?', "%#{search}%"]).order(:no).page(param_page)
      end
    else
      if search_type_id != ''
        Master.where(['type1_id = ? or type2_id = ?', search_type_id.to_s, search_type_id.to_s]).order(:no).page(param_page)
      else
        Master.order(:no).page(param_page)
      end
    end
  end
end
