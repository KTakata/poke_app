class Type < ActiveRecord::Base
  has_many :weak_compatibilities, class_name: 'WeakCompatibility', foreign_key: 'type1_id'
  has_many :own_compatibilities, class_name: 'WeakCompatibility', foreign_key: 'type2_id'
  has_many :strong_compatibilities, class_name: 'StrongCompatibility', foreign_key: 'type1_id'
  has_many :target_compatibilities, class_name: 'StrongCompatibility', foreign_key: 'type2_id'
  has_many :master1, class_name: 'Master', foreign_key: 'type1_id'
  has_many :master2, class_name: 'Master', foreign_key: 'type2_id'
  has_many :skill, class_name: 'Skill', foreign_key: 'type_id'

  def self.own_lists_with_blank
    types = self.all.order(:sort_num)
    @hash_list = []
    obj = ['', nil]
    @hash_list.push(obj)
    types.each do |t|
      obj = [t.jap_name_kana, t.id]
      @hash_list.push(obj)
    end
    @hash_list
  end

  def master_ids
    type_ids = []
    type_ids.concat(master1_ids) if master1_ids.count != 0
    type_ids.concat(master2_ids) if master2_ids.count != 0
    type_ids
  end

  def masters
    masters = Master.where(['type1_id = ? or type2_id = ?', id, id])
    masters
  end
end
