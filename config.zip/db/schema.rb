# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170307053108) do

  create_table "battle_types", force: :cascade do |t|
    t.string   "label"
    t.string   "order"
    t.boolean  "is_active"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "birthplaces", force: :cascade do |t|
    t.string   "label"
    t.string   "order"
    t.boolean  "is_active"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "characteristics", force: :cascade do |t|
    t.string   "name"
    t.text     "effect"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "item_types", force: :cascade do |t|
    t.string   "label"
    t.string   "order"
    t.boolean  "is_active"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "items", force: :cascade do |t|
    t.string   "name"
    t.string   "effect1"
    t.string   "effect2"
    t.string   "place1"
    t.string   "place2"
    t.string   "place3"
    t.string   "place4"
    t.string   "place5"
    t.string   "place6"
    t.integer  "item_type_id"
    t.boolean  "is_active"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  add_index "items", ["item_type_id"], name: "index_items_on_item_type_id"

  create_table "masters", force: :cascade do |t|
    t.string   "no"
    t.string   "name"
    t.integer  "type1_id"
    t.integer  "type2_id"
    t.integer  "hp"
    t.integer  "attack"
    t.integer  "block"
    t.integer  "contact"
    t.integer  "deffence"
    t.integer  "speed"
    t.integer  "total"
    t.integer  "height"
    t.integer  "weight"
    t.string   "form"
    t.integer  "characteristic1_id"
    t.integer  "characteristic2_id"
    t.integer  "characteristic3_id"
    t.datetime "created_at",         null: false
    t.datetime "updated_at",         null: false
  end

  add_index "masters", ["characteristic1_id"], name: "index_masters_on_characteristic1_id"
  add_index "masters", ["characteristic2_id"], name: "index_masters_on_characteristic2_id"
  add_index "masters", ["characteristic3_id"], name: "index_masters_on_characteristic3_id"
  add_index "masters", ["type1_id"], name: "index_masters_on_type1_id"
  add_index "masters", ["type2_id"], name: "index_masters_on_type2_id"

  create_table "member_skills", force: :cascade do |t|
    t.integer  "skill_id"
    t.integer  "member_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "member_skills", ["member_id"], name: "index_member_skills_on_member_id"
  add_index "member_skills", ["skill_id"], name: "index_member_skills_on_skill_id"

  create_table "members", force: :cascade do |t|
    t.integer  "level"
    t.integer  "user_id"
    t.integer  "master_id"
    t.string   "nick_name"
    t.integer  "hp"
    t.integer  "attack"
    t.integer  "block"
    t.integer  "contact"
    t.integer  "deffence"
    t.integer  "speed"
    t.integer  "original_hp"
    t.integer  "original_attack"
    t.integer  "original_block"
    t.integer  "original_contact"
    t.integer  "original_deffence"
    t.integer  "original_speed"
    t.integer  "personality_id"
    t.boolean  "is_other_color"
    t.text     "remaks"
    t.integer  "characteristic_id"
    t.integer  "gendar"
    t.decimal  "fif_h"
    t.decimal  "fif_a"
    t.decimal  "fif_b"
    t.decimal  "fif_c"
    t.decimal  "fif_d"
    t.decimal  "fif_s"
    t.boolean  "is_status_lock"
    t.boolean  "is_agenda"
    t.boolean  "crown_h"
    t.boolean  "crown_a"
    t.boolean  "crown_b"
    t.boolean  "crown_c"
    t.boolean  "crown_d"
    t.boolean  "crown_s"
    t.integer  "birthplace_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  add_index "members", ["birthplace_id"], name: "index_members_on_birthplace_id"
  add_index "members", ["characteristic_id"], name: "index_members_on_characteristic_id"
  add_index "members", ["master_id"], name: "index_members_on_master_id"
  add_index "members", ["personality_id"], name: "index_members_on_personality_id"
  add_index "members", ["user_id"], name: "index_members_on_user_id"

  create_table "participating_regions", force: :cascade do |t|
    t.integer  "party_id"
    t.integer  "birthplace_id"
    t.boolean  "is_active"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
  end

  add_index "participating_regions", ["birthplace_id"], name: "index_participating_regions_on_birthplace_id"
  add_index "participating_regions", ["party_id"], name: "index_participating_regions_on_party_id"

  create_table "parties", force: :cascade do |t|
    t.text     "remarks"
    t.string   "name"
    t.integer  "user_id"
    t.integer  "battle_type_id"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
  end

  add_index "parties", ["battle_type_id"], name: "index_parties_on_battle_type_id"
  add_index "parties", ["user_id"], name: "index_parties_on_user_id"

  create_table "party_members", force: :cascade do |t|
    t.integer  "party_id"
    t.string   "member"
    t.integer  "item_id"
    t.integer  "no"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "party_members", ["item_id"], name: "index_party_members_on_item_id"
  add_index "party_members", ["party_id"], name: "index_party_members_on_party_id"

  create_table "personalities", force: :cascade do |t|
    t.string   "name"
    t.string   "up_status"
    t.string   "down_status"
    t.boolean  "is_synchro"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "reports", force: :cascade do |t|
    t.string   "title"
    t.date     "start_date"
    t.date     "end_date"
    t.text     "content"
    t.integer  "party_id"
    t.integer  "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "reports", ["party_id"], name: "index_reports_on_party_id"
  add_index "reports", ["user_id"], name: "index_reports_on_user_id"

  create_table "samples", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "skills", force: :cascade do |t|
    t.string   "name"
    t.integer  "type_id"
    t.integer  "effect_type"
    t.integer  "power"
    t.string   "hit"
    t.integer  "pp"
    t.boolean  "is_direct"
    t.text     "effect"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  add_index "skills", ["type_id"], name: "index_skills_on_type_id"

  create_table "strong_compatibilities", force: :cascade do |t|
    t.integer  "type1_id"
    t.integer  "type2_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "strong_compatibilities", ["type1_id"], name: "index_strong_compatibilities_on_type1_id"
  add_index "strong_compatibilities", ["type2_id"], name: "index_strong_compatibilities_on_type2_id"

  create_table "todos", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "title"
    t.text     "remarks"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "todos", ["user_id"], name: "index_todos_on_user_id"

  create_table "types", force: :cascade do |t|
    t.string   "name"
    t.string   "jap_name"
    t.string   "jap_name_kana"
    t.integer  "sort_num"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
  end

  create_table "users", force: :cascade do |t|
    t.string   "name"
    t.string   "username"
    t.string   "password"
    t.string   "email"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.string   "password_digest"
    t.string   "remember_token"
  end

  create_table "weak_compatibilities", force: :cascade do |t|
    t.integer  "type1_id"
    t.integer  "type2_id"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.boolean  "is_zero_damage"
  end

  add_index "weak_compatibilities", ["type1_id"], name: "index_weak_compatibilities_on_type1_id"
  add_index "weak_compatibilities", ["type2_id"], name: "index_weak_compatibilities_on_type2_id"

end
